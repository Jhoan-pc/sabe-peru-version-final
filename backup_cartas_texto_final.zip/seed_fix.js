import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xdslypbjmenthwyrarui.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhkc2x5cGJqbWVudGh3eXJhcnVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEwMTYzMzcsImV4cCI6MjA4NjU5MjMzN30.1ujAkNw4jcXhQLXtPnbJCjx3LNn7Zf8YRgXsi0s0LeY'
const supabase = createClient(supabaseUrl, supabaseKey)

const menuItems = [
    // --- COMIDA: ENTRADAS ---
    { name: 'Ceviche de Corvina', description: 'Finos cortes de corvina frescos del día, marinados en jugo de limón y leche de tigre. Acompañado de choclo y camote glaseado.', price: 23.00, category: 'comida' },
    { name: 'Ceviche Mixto Sabe a Perú', description: 'Cortes de pescado y mixtura de mariscos marinados en leche de tigre con salsa de rocoto y ají amarillo.', price: 25.00, category: 'comida' },
    { name: 'Causa Limeña de Pollo', description: 'Capa suave de papa amarilla rellena de pollo deshilachado, zanahoria y cilantro. Coronada con aceituna y huevo.', price: 14.00, category: 'comida' },
    { name: 'Causa Acevichada', description: 'Papa amarilla rellena de aguacate, coronada con cortes de pescado marinado en leche de tigre.', price: 17.00, category: 'comida' },
    { name: 'Causa Sabe a Perú', description: 'Croquetas crujientes de causa coronadas con choclos a la huancaína y lomo saltado jugoso.', price: 17.00, category: 'comida' },
    { name: 'Tiradito Sabe a Perú', description: 'Finas tiras de pescado en salsa suave de ají amarillo y maracuyá, con granos de choclo y camote.', price: 23.00, category: 'comida' },
    { name: 'Anticuchos (3 brochetas)', description: 'Brochetas de corazón de res marinadas en salsa anticuchera, servidas con papas a la huancaína y choclo.', price: 12.00, category: 'comida' },
    { name: 'Choritos a la Chalaca', description: '10 unidades de mejillones frescos con mezcla de cebolla, tomate, choclo y ají en jugo de limón.', price: 12.00, category: 'comida' },

    // --- COMIDA: FONDOS ---
    { name: 'Lomo Saltado', description: 'Jugosos trozos de carne de res salteados al wok con cebolla, tomate y un toque de la casa. Servido con arroz y papas.', price: 20.00, category: 'comida' },
    { name: 'Solomillo a lo Macho', description: 'Jugoso solomillo de res con salsa a lo macho elaborada con mariscos frescos y ajíes peruanos.', price: 25.00, category: 'comida' },
    { name: 'Arroz con Mariscos', description: 'Arroz con mariscos frescos, ajíes peruanos y salsa madre de mariscos. Servido con salsa criolla y parmesano.', price: 22.00, category: 'comida' },
    { name: 'Chaufa de Mariscos', description: 'Arroz salteado al wok con mariscos frescos, cebollín, huevo y toques de salsa de soja y aceite de sésamo.', price: 20.00, category: 'comida' },
    { name: 'Chaufa de Carne', description: 'Arroz salteado al wok con trozos de carne, cebollín, huevo y jengibre.', price: 20.00, category: 'comida' },
    { name: 'Tacu Tacu de Lomo Saltado', description: 'Combinación crujiente de arroz y frijoles con el sabor intenso de nuestro lomo saltado y huevo frito.', price: 22.00, category: 'comida' },
    { name: 'Tallarines Saltados de Carne', description: 'Tallarines salteados con carne de vacuno, cebolla, tomate, pimiento y salsa de la casa.', price: 20.00, category: 'comida' },
    { name: 'Spaghetti a la Huancaína con Lomo', description: 'Espaguetis bañados en salsa a lo huancaína con trozos de carne de res tierna y salsa de soja.', price: 20.00, category: 'comida' },
    { name: 'Jalea Mixta', description: 'Mariscos y pescado apanados y fritos con yuca frita y salsa criolla.', price: 25.00, category: 'comida' },
    { name: 'Chicharrón de Pescado', description: 'Trozos de pescado fresco apanados y fritos. Acompañados de yucas fritas y salsa criolla.', price: 20.00, category: 'comida' },
    { name: 'Chicharrón de Cerdo', description: 'Cortes de cerdo cocinados hasta lograr una textura crujiente. Con patatas doradas y salsa criolla.', price: 18.00, category: 'comida' },

    // --- COMIDA: HAMBURGUESAS Y ENSALADAS ---
    { name: 'Hamburguesa Sabe a Perú', description: 'Pan brioche, papas fritas, carne, queso gouda, cebolla, tomate y salsa de lomo saltado con huancaína.', price: 15.00, category: 'comida' },
    { name: 'Hamburguesa XXL', description: 'Doble carne, queso gouda, cheddar, tocino y huevo. Acompañada de patatas y mayo-ajo.', price: 16.00, category: 'comida' },
    { name: 'Hamburguesa Hawaiana', description: 'Carne, queso, tocino, piña caramelizada, patatas fritas y mayo-ajo.', price: 14.00, category: 'comida' },
    { name: 'Ensalada Tataki', description: 'Tataki de atún con sésamo sobre lechuga, cebolla, tomate, huevo y palta con vinagreta exótica.', price: 12.00, category: 'comida' },

    // --- BEBIDAS ---
    { name: 'Cerveza Cusqueña (Negra/Dorada/Trigo)', description: 'Cerveza premium peruana de gran tradición.', price: 3.00, category: 'bebida' },
    { name: 'Inca Kola', description: 'La bebida nacional del Perú de sabor único.', price: 3.00, category: 'bebida' },
    { name: 'Chicha Morada (Vaso)', description: 'Infusión natural de maíz morado, piña y especias.', price: 5.00, category: 'bebida' },
    { name: 'Chicha Morada (Jarra)', description: 'Nuestra chicha artesanal para compartir.', price: 12.00, category: 'bebida' },
    { name: 'Batido de Fruta (Maracuyá/Mango/Lulo...)', description: 'Batidos naturales preparados al momento.', price: 5.00, category: 'bebida' },
    { name: 'Pisco Sour', description: 'Cóctel emblemático del Perú preparado con maestría.', price: 8.00, category: 'coctel' },
    { name: 'Vino Ramón Bilbao (Rioja)', description: 'Selección de la casa.', price: 19.00, category: 'bebida' },
    { name: 'Vino Godello', description: 'Blanco selecto.', price: 18.00, category: 'bebida' }
]

async function seed() {
    console.log('--- Corrigiendo Carta (Fiel a la carta física) ---')
    await supabase.from('menu_items').delete().neq('id', '00000000-0000-0000-0000-000000000000')
    const { error } = await supabase.from('menu_items').insert(menuItems)
    if (error) console.error('Error:', error)
    else console.log('¡Carta corregida y sincronizada!')
}

seed()
