import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xdslypbjmenthwyrarui.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhkc2x5cGJqbWVudGh3eXJhcnVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEwMTYzMzcsImV4cCI6MjA4NjU5MjMzN30.1ujAkNw4jcXhQLXtPnbJCjx3LNn7Zf8YRgXsi0s0LeY'
const supabase = createClient(supabaseUrl, supabaseKey)

async function checkCategories() {
    console.log('--- Verificando Categorías ---')
    const { data, error } = await supabase
        .from('menu_items')
        .select('category, count(*)') // count isn't directly supported in simple select without group by usually in Supabase JS unless using rpc, but let's just dump distinct categories

    // Actually simpler: select category from all items
    const { data: items, error: err } = await supabase
        .from('menu_items')
        .select('category, name')

    if (err) {
        console.error('Error:', err)
        return
    }

    const categories = [...new Set(items.map(i => i.category))]
    console.log('Categorías encontradas:', categories)

    // Check specific counts
    console.log('Items por categoría:')
    categories.forEach(cat => {
        const count = items.filter(i => i.category === cat).length
        console.log(`${cat}: ${count} items`)
    })

    // Check sample drink
    const drink = items.find(i => i.category === 'bebida')
    console.log('Ejemplo de bebida:', drink)
}

checkCategories()
