import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xdslypbjmenthwyrarui.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhkc2x5cGJqbWVudGh3eXJhcnVpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEwMTYzMzcsImV4cCI6MjA4NjU5MjMzN30.1ujAkNw4jcXhQLXtPnbJCjx3LNn7Zf8YRgXsi0s0LeY'
const supabase = createClient(supabaseUrl, supabaseKey)

// Note: Direct ALTER TABLE via JS client is not supported by Supabase JS.
// I have to use a different approach. I'll use the 'price' field as 0 
// and put the formatted price in a new field if possible, or just hack the description.
// Actually, I can use the description but I need it to LOOK GOOD.

// Let's try to add a 'formatted_price' column if possible? No.
// I'll use the 'image_url' or some other unused column as a holder for the price string if needed?
// No, that's bad.

// Best approach: I'll make the main.ts handle specific patterns in the 'name' or 
// use a very specific delimiter in 'description'.

const menuItems = [
    // --- ENTRADAS (Category: comida, Sub: ENTRADAS) ---
    { name: 'Causa limeña de pollo', description: 'Capa suave de papa amarilla amasada, rellena de pollo deshilachado, mezclado con mayonesa, zanahoria, alverjas y cilantro, coronada con aceitunas negras, huevo duro.', price: 14.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 1, tags: ['pollo'] },
    { name: 'Causa acevichada', description: 'Capa suave de papa amarilla amasada, rellena de aguacate, y coronada de finos cortes de pescado marinado en jugo de limon y leche de tigre, mezclado con cebolla morada, cilantro, ají, acompañada de choclo peruano y cancha.', price: 17.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 2, tags: ['pescado', 'picante'] },
    { name: 'Causa Sabe a Perú', description: 'Croquetas crujientes de causa, coronadas con choclos a la huancaina y un lomo saltado jugoso (trozos de carne, cebolla, tomate).', price: 17.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 3, tags: ['carne'] },
    { name: 'Ceviche de corvina', description: 'Finos cortes de corvina frescos del día, marinados en jugo de limón y leche de tigre, mezclados con cebolla morada y finos cortes de cilantro y ají, acompañados con cancha crujiente y tiernos granos de choclo y cortes de camote glaseado.', price: 23.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 4, tags: ['pescado', 'picante', 'gluten-free'] },
    { name: 'Ceviche mixto Sabe a Perú', description: 'Cortes de pescado y una mixtura de mariscos marinados en jugo de limón y leche de tigre, con cortes de cebolla y cilantro, coronada con una salsa de rocoto y ají amarillo, acompañado de camote glaseado, granos de choclo y canchita crocante.', price: 25.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 5, tags: ['pescado', 'marisco', 'picante', 'gluten-free'] },
    { name: 'Tiradito Sabe a Perú', description: 'Finas tiras de pescado marinadas en jugo de limon, colocadas sobre una salsa suave de aji amarillo y maracuyá, acompañadas de granos de choclo y trozos de camote glaseados.', price: 23.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 6, tags: ['pescado', 'picante'] },
    { name: 'Anticuchos 3 brochetas', description: 'Tradicional plato peruano. Brochetas de corazón de res marinadas en una salsa anticuchera (ají panka, vinagre, ajos y especias), acompañadas de papas a la huancaina y granos de choclo.', price: 12.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 7, tags: ['carne', 'picante'] },
    { name: 'Choritos a la chalaca 10 und.', description: 'Mejillones frescos al natural, bañados con una colorida mezcla de cebolla, cilantro, tomate, choclo y ají, sazonados con jugo de limón y leche de tigre.', price: 12.00, category: 'comida', subcategory: 'ENTRADAS', sort_order: 8, tags: ['marisco', 'picante', 'gluten-free'] },

    // --- PLATOS DE FONDO (Category: comida, Sub: PLATOS DE FONDO) ---
    { name: 'Arroz con mariscos', description: 'Una mezcla de arroz con granos de choclos y arvejas, mariscos frescos salteado con cebollín, salsa madre de mariscos y toques de vino blanco acompañado de una salsa criolla y coronado con queso parmesano.', price: 22.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 10, tags: ['marisco'] },
    { name: 'Chaufa de mariscos', description: 'Arroz salteado al wok con una seleccion de mariscos frescos salteado con cebollín, huevo, toques de ajo, jengibre brotes de soya, toques de salsa de soja y aceite de sesamo.', price: 20.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 11, tags: ['marisco'] },
    { name: 'Chaufa de carne', description: 'Arroz salteado al wok con trozos de carne, salteado con cebollín, huevo, toques de ajo, jengibre brotes de soja, toques de salsa de soja y aceite de sesamo.', price: 20.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 12, tags: ['carne'] },
    { name: 'Tacu tacu de lomo saltado montado', description: 'Un plato que combina la textura crujiente del tacu tacu (arroz y frijoles cocidos con un aderezo de la casa) con la sabrosura intensa de un lomo saltado, montado con un huevo frito.', price: 22.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 13, tags: ['carne'] },
    { name: 'Lomo Saltado', description: 'Jugosos trozos de carne de res salteados al wok con cebolla morada, tomate, flameados con salsa de soya y un toque de vinagre y una salsa de la casa, servido con arroz blanco y patatas fritas.', price: 20.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 14, tags: ['carne'] },
    { name: 'Tallarines saltados de carne', description: 'Tallarines salteados con trozos de carne de vacuno, cebolla, tomate, brotes de soya, morron, cebollin, toques de salsa de soya, aceite de sésamo y una salsa de la casa.', price: 20.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 15, tags: ['carne'] },
    { name: 'Spaghetti a la huancaina con lomo', description: 'Deliciosos y cremosos espaguetis bañados con una salsa a la huancaina, elaborada con ají amarillo, queso fresco y leche, coronados con un jugoso lomo saltado.', price: 20.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 16, tags: ['carne', 'picante'] },
    { name: 'Jalea mixta', description: 'Mariscos y pescado, apanados y fritos, acompañados con yuca frita y una salsa criolla. Un plato sabroso y crujiente de la cocina peruana.', price: 25.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 17, tags: ['pescado', 'marisco'] },
    { name: 'Chicharrón de pescado', description: 'Trozos de pescados frescos apanados y fritos hasta alcanzar una textura crujiente y dorada, acompañados de unas yucas fritas y salsa criolla.', price: 20.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 18, tags: ['pescado'] },
    { name: 'Chicharrón de cerdo', description: 'Cortes de cerdo cocinados lentamente hasta lograr una textura crocante y dorada, acompañados de patatas doradas y una salsa criolla de cebolla y hierbabuena.', price: 18.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 19, tags: ['carne'] },
    { name: 'Solomillo a lo macho', description: 'Jugoso solomillo de res, cocinado al punto y cubierto con una salsa a lo macho, elaborada con mariscos frescos y ajíes peruanos.', price: 25.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 20, tags: ['carne', 'marisco', 'picante'] },
    { name: 'Mostrito', description: 'Crocante pollo broaster acompañado con patatas fritas y un delicioso arroz chaufa (arroz salteado al wok con huevo, toques de cebollin, salsa de soja y aceite de sesamo).', price: 18.00, category: 'comida', subcategory: 'PLATOS DE FONDO', sort_order: 21, tags: ['pollo'] },

    // --- HAMBURGUESAS (Category: comida, Sub: HAMBURGUESAS) ---
    { name: 'Hamburguesa XXL', description: 'Pan Brioche, doble carne con queso gouda y queso cheddar, tocino y huevo acompañado de patatas fritas y mayo ajo.', price: 16.00, category: 'comida', subcategory: 'HAMBURGUESAS', sort_order: 30, tags: ['carne'] },
    { name: 'Hamburguesa Hawaiana', description: 'Pan brioche, lechuga, carne, queso, tocino, queso gouda, piña caramelizada acompañados de patatas fritas y mayo ajo.', price: 14.00, category: 'comida', subcategory: 'HAMBURGUESAS', sort_order: 31, tags: ['carne'] },
    { name: 'Hamburguesa Sabe a Perú', description: 'Pan brioche, cama de patatas fritas, carne, queso gouda, cebolla y tomate salteados con salsa de lomo y huevo, acompañado con patatas fritas y salsa huancaina.', price: 15.00, category: 'comida', subcategory: 'HAMBURGUESAS', sort_order: 32, tags: ['carne', 'picante'] },

    // --- ENSALADAS (Category: comida, Sub: ESPECIALIDADES Y ENSALADAS) ---
    { name: 'Alitas acevichadas', description: 'Deliciosas alitas broster bañadas en una salsa acevichada con cebolla y toques de cilantro, acompañados de patatas fritas.', price: 15.00, category: 'comida', subcategory: 'ESPECIALIDADES Y ENSALADAS', sort_order: 40, tags: ['pollo', 'picante'] },
    { name: 'Frescura tropical', description: 'Mezcla fresca de lechuga, tomate, pepinillo y cebolla morada, combinada con jugosa piña y tiernos trozos de pollo a la plancha. Acompañada con una vinagreta artesanal de maracuyá.', price: 11.00, category: 'comida', subcategory: 'ESPECIALIDADES Y ENSALADAS', sort_order: 41, tags: ['pollo', 'gluten-free'] },
    { name: 'Ensalada tataki', description: 'Tataki de atún con sésamo, servido sobre una fresca cama de lechuga con cebolla morada, tomate, huevo y suaves trozos de palta. Vinagreta exótica.', price: 12.00, category: 'comida', subcategory: 'ESPECIALIDADES Y ENSALADAS', sort_order: 42, tags: ['pescado', 'gluten-free'] },

    // --- POSTRES (Category: comida, Sub: POSTRES) ---
    { name: 'Choco maracuyá', description: '', price: 6.00, category: 'comida', subcategory: 'POSTRES', sort_order: 50, tags: [] },
    { name: 'Torta 3 leches', description: '', price: 6.00, category: 'comida', subcategory: 'POSTRES', sort_order: 51, tags: [] },
    { name: 'Crema volteada', description: '', price: 5.00, category: 'comida', subcategory: 'POSTRES', sort_order: 52, tags: [] },
    { name: 'Arroz con leche', description: '', price: 5.00, category: 'comida', subcategory: 'POSTRES', sort_order: 53, tags: [] },
    { name: 'Brownie con helado', description: '', price: 6.00, category: 'comida', subcategory: 'POSTRES', sort_order: 54, tags: [] },
    { name: 'Helado de la casa', description: '', price: 5.00, category: 'comida', subcategory: 'POSTRES', sort_order: 55, tags: [] },

    // --- BEBIDAS (Category: bebida, Sub: BEBIDAS Y BATIDOS) ---
    { name: 'Cerveza Cusqueña negra', description: '', price: 3.00, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 60, tags: [] },
    { name: 'Cerveza Cusqueña dorada', description: '', price: 3.00, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 61, tags: [] },
    { name: 'Cerveza Cusqueña de trigo', description: '', price: 3.00, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 62, tags: [] },
    { name: 'Cerveza Pilsen', description: '', price: 3.00, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 63, tags: [] },
    { name: 'Inca kola', description: '', price: 3.00, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 64, tags: [] },
    { name: 'Chicha morada', description: 'Vaso 5,00€ / Jarra 12,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 65, tags: [] },
    { name: 'Limonada frozen', description: 'Vaso 5,00€ / Jarra 12,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 66, tags: [] },
    { name: 'Pisco sour', description: '', price: 8.00, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 67, tags: [] },
    // { name: 'Batidos de Fruta', description: 'Piña, Maracuyá, Mango, Fresa, Mora, Guanábana, Papaya, Tamarindo, Lulo, Tomate de árbol, Guayaba. Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 70, tags: [] },
    { name: 'Batido de Piña', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 70, tags: [] },
    { name: 'Batido de Maracuyá', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 71, tags: [] },
    { name: 'Batido de Mango', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 72, tags: [] },
    { name: 'Batido de Fresa', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 73, tags: [] },
    { name: 'Batido de Mora', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 74, tags: [] },
    { name: 'Batido de Guanábana', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 75, tags: [] },
    { name: 'Batido de Papaya', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 76, tags: [] },
    { name: 'Batido de Tamarindo', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 77, tags: [] },
    { name: 'Batido de Lulo', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 78, tags: [] },
    { name: 'Batido de Tomate de árbol', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 79, tags: [] },
    { name: 'Batido de Guayaba', description: 'Vaso 5,00€ / Jarra 11,00€', price: 0, category: 'bebida', subcategory: 'BEBIDAS Y BATIDOS', sort_order: 80, tags: [] },

    // --- VINOS (Category: bebida, Sub: VINOS) ---
    { name: 'Ramon Bilbao', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS', sort_order: 90, tags: [] },
    { name: 'Azpilicueta', description: '', price: 19.50, category: 'bebida', subcategory: 'VINOS', sort_order: 91, tags: [] },
    { name: 'Izadi', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS', sort_order: 92, tags: [] },
    { name: 'Beronia', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS', sort_order: 93, tags: [] },
    { name: 'Ribera', description: '', price: 18.00, category: 'bebida', subcategory: 'VINOS', sort_order: 94, tags: [] },
    { name: 'Rueda', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS', sort_order: 95, tags: [] },
    { name: 'Valviejo verdejo', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS', sort_order: 96, tags: [] },
    { name: 'Albarino', description: '', price: 16.00, category: 'bebida', subcategory: 'VINOS', sort_order: 97, tags: [] },
    { name: 'GodellO', description: '', price: 16.00, category: 'bebida', subcategory: 'VINOS', sort_order: 98, tags: [] },
    { name: 'Vino rosado', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS', sort_order: 99, tags: [] },
    { name: 'Moscato', description: '', price: 16.00, category: 'bebida', subcategory: 'VINOS', sort_order: 100, tags: [] },

    // --- VINOS ROSADOS (Category: bebida, Sub: VINOS ROSADOS) ---
    { name: 'Prieto picudo', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS ROSADOS', sort_order: 110, tags: [] },
    { name: 'Navarra', description: '', price: 19.00, category: 'bebida', subcategory: 'VINOS ROSADOS', sort_order: 111, tags: [] },

    // --- SANGRÍA (Category: bebida, Sub: SANGRÍA) ---
    { name: 'Vino de la casa', description: '', price: 16.00, category: 'bebida', subcategory: 'SANGRÍA', sort_order: 120, tags: [] }
]

async function seed() {
    console.log('--- Aplicando Ordenación Definitiva ---')
    await supabase.from('menu_items').delete().neq('id', '00000000-0000-0000-0000-000000000000')
    const { error } = await supabase.from('menu_items').insert(menuItems)
    if (error) console.error('Error:', error)
    else console.log('¡Sincronización completa con el estilo de la carta física!')
}

seed()
