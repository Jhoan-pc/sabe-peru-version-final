-- Tabla para las reservas
CREATE TABLE reservations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now(),
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  reservation_date DATE NOT NULL,
  reservation_time TIME,
  number_of_people INTEGER NOT NULL,
  occasion TEXT,
  status TEXT DEFAULT 'pending' -- pending, confirmed, cancelled
);

-- Tabla para el menú digital
CREATE TABLE menu_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMPTZ DEFAULT now(),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  category TEXT NOT NULL,
  subcategory TEXT,      -- Nuevo: Entradas, Fondos, etc.
  sort_order INTEGER DEFAULT 0, -- Nuevo: Para el orden exacto
  image_url TEXT,
  is_available BOOLEAN DEFAULT true
);

-- Habilitar Row Level Security (RLS)
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;

-- Políticas: Reservas y Menú
CREATE POLICY "Enable insert for everyone" ON reservations FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable read for everyone" ON menu_items FOR SELECT USING (true);
CREATE POLICY "Enable insert for everyone" ON menu_items FOR INSERT WITH CHECK (true); -- Permitir carga inicial
