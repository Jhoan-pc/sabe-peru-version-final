import './style.css'
import { supabase } from './supabase'

document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('main-header');
  const tabs = document.querySelectorAll('.tab-link');
  const reservationForm = document.getElementById('reservation-form') as HTMLFormElement;
  const formMessage = document.getElementById('form-message');
  const menuGrid = document.getElementById('menu-grid');

  // --- Header Transparency Effect ---
  const isHomePage = window.location.pathname === '/' || window.location.pathname.endsWith('index.html');

  const updateHeader = () => {
    if (window.scrollY > 80 || !isHomePage) {
      header?.classList.add('scrolled');
    } else {
      header?.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', updateHeader);
  updateHeader(); // Check on load

  // --- Reveal Animations on Scroll ---
  const revealElements = document.querySelectorAll('.reveal');
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px"
  };

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
      }
    });
  }, observerOptions);

  revealElements.forEach(el => revealObserver.observe(el));

  // --- Smooth Scroll & Navigation ---
  tabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      const href = tab.getAttribute('href') || '';

      // If it's a link to another page (like carta.html), let it be
      if (href.includes('.html')) return;

      if (href.startsWith('#')) {
        const target = document.querySelector(href) as HTMLElement;
        if (target) {
          e.preventDefault();
          window.scrollTo({
            top: target.offsetTop - 80,
            behavior: 'smooth'
          });
        }
      }
    });
  });

  // --- Header Active State on Scroll (Home Page) ---
  if (isHomePage) {
    window.addEventListener('scroll', () => {
      let current = "";
      document.querySelectorAll('section[id]').forEach((section) => {
        const sectionTop = (section as HTMLElement).offsetTop;
        if (window.pageYOffset >= sectionTop - 150) {
          current = section.getAttribute("id") || "";
        }
      });

      tabs.forEach((tab) => {
        tab.classList.remove("active");
        if (tab.getAttribute("href") === `#${current}`) {
          tab.classList.add("active");
        }
      });
    });
  }

  // --- MENU LOGIC (Only if menu grid exists) ---
  if (menuGrid) {
    const filterBtns = document.querySelectorAll('.filter-btn');

    async function loadMenu(category: string) {
      menuGrid!.innerHTML = '<div class="loading-state">Actualizando selección...</div>';

      try {
        const { data, error } = await supabase
          .from('menu_items')
          .select('*')
          .eq('is_available', true)
          .eq('category', category)
          .order('sort_order', { ascending: true });

        if (error) throw error;

        if (!data || data.length === 0) {
          menuGrid!.innerHTML = `<div class="loading-state">Próximamente novedades en ${category}s.</div>`;
          return;
        }

        // Group by subcategory
        const groups: { [key: string]: any[] } = {};
        data.forEach((item: any) => {
          const sub = item.subcategory || 'OTROS';
          if (!groups[sub]) groups[sub] = [];
          groups[sub].push(item);
        });

        const tagIcons: { [key: string]: string } = {
          'pescado': '<span class="menu-tag" title="Pescado">🐟</span>',
          'marisco': '<span class="menu-tag" title="Marisco">🦐</span>',
          'carne': '<span class="menu-tag" title="Carne">🥩</span>',
          'pollo': '<span class="menu-tag" title="Pollo">🍗</span>',
          'picante': '<span class="menu-tag" title="Picante">🌶️</span>',
          'gluten-free': '<span class="menu-tag" title="Sin Gluten">🌾</span>'
        };

        let html = '';
        for (const sub in groups) {
          html += `<div class="menu-subcategory-title">${sub}</div>`;
          html += groups[sub].map((item: any) => {
            const hasNumericPrice = item.price > 0;
            let priceDisplay = hasNumericPrice ? `${parseFloat(item.price).toFixed(2)}€` : item.description;
            let descriptionDisplay = hasNumericPrice ? (item.description || '') : '';

            // Handle very long dual prices (optional styling class)
            const priceClass = !hasNumericPrice ? 'menu-item-price dual' : 'menu-item-price';

            const icons = (item.tags || []).map((tag: string) => tagIcons[tag] || '').join('');

            return `
              <div class="menu-item reveal active">
                <div class="menu-item-header">
                  <h3>${item.name}${icons}</h3>
                  <span class="${priceClass}">${priceDisplay}</span>
                </div>
                ${descriptionDisplay ? `
                <div class="menu-item-info">
                  <p>${descriptionDisplay}</p>
                </div>` : ''}
              </div>
            `;
          }).join('');
        }
        menuGrid!.innerHTML = html;

      } catch (err) {
        console.error('Error loading menu:', err);
        menuGrid!.innerHTML = '<div class="loading-state">Estamos ordenando los sabores. Por favor, refresca en un momento.</div>';
      }
    }

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.getAttribute('data-category') || 'comida';
        loadMenu(cat);
      });
    });

    // Check URL params for initial category
    const urlParams = new URLSearchParams(window.location.search);
    const initialCat = urlParams.get('cat') || 'comida';

    // Set active button
    filterBtns.forEach(btn => {
      if (btn.getAttribute('data-category') === initialCat) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Initial load
    loadMenu(initialCat);
  }

  // --- RESERVATION LOGIC ---
  if (reservationForm) {
    reservationForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = reservationForm.querySelector('button[type="submit"]') as HTMLButtonElement;

      if (submitBtn) submitBtn.disabled = true;
      if (formMessage) {
        formMessage.textContent = 'Procesando su solicitud...';
        formMessage.className = 'form-message';
      }

      const formData = new FormData(reservationForm);
      const reservation = {
        customer_name: formData.get('name'),
        customer_email: formData.get('email'),
        reservation_date: formData.get('date'),
        reservation_time: formData.get('time'),
        number_of_people: parseInt(formData.get('people') as string),
        occasion: formData.get('occasion'),
        status: 'pending'
      };

      try {
        const { error } = await supabase
          .from('reservations')
          .insert([reservation]);

        if (error) throw error;

        if (formMessage) {
          formMessage.textContent = '¡Reserva recibida! Le contactaremos pronto por email.';
          formMessage.className = 'form-message success';
        }
        reservationForm.reset();
      } catch (err) {
        console.error('Error saving reservation:', err);
        if (formMessage) {
          formMessage.textContent = 'Hubo un error. Por favor, llámenos directamente.';
          formMessage.className = 'form-message error';
        }
      } finally {
        if (submitBtn) submitBtn.disabled = false;
      }
    });
  }
});
